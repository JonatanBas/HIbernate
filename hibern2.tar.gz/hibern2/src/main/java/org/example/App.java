package org.example;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session ss = sf.openSession();
        Transaction tr = ss.beginTransaction();

        Profesor p1 = new Profesor(1,"Miguel",1800);
        Profesor p2 = new Profesor(2, "Raul", 1700);

        Alumno a1 = new Alumno(1,"Alfonso", 27);
        Alumno a2 = new Alumno(2,"Daniel",31);

        ss.persist(p1);
        ss.persist(p2);

        ss.persist(a1);
        ss.persist(a2);

        tr.commit();
    }
}
