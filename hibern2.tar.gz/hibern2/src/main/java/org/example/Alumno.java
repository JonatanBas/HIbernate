package org.example;

import jakarta.persistence.Column;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;

import java.util.List;

public class Alumno
{
    //ATRIBUTOS
    @Id
    private Long id;
    @Column
    private String nombre;
    @Column
    private int edad;
    @ManyToMany(mappedBy = "ListaAlumnos")
    protected List<Profesor> ListaProfesores;


    //CONSTRUCTORES
    public Alumno(Long id, String nombre, int edad, List<Profesor> listaProfesores) {
        this.id = id;
        this.nombre = nombre;
        this.edad = edad;
        ListaProfesores = listaProfesores;
    }

    public Alumno(int i, String alfonso, int i1) {
    }

    //SETTERS
    /*public void setId(Long id) {
        this.id = id;
    }*/

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setListaProfesores(List<Profesor> listaProfesores) {
        ListaProfesores = listaProfesores;
    }

    //GETTERS
    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public List<Profesor> getListaProfesores() {
        return ListaProfesores;
    }

    //TOSTRING

    @Override
    public String toString() {
        return "Alumno{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", edad=" + edad +
                ", ListaProfesores=" + ListaProfesores +
                '}';
    }
}
